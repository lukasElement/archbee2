This package contains a hyperscript helper for creating Slate documents with JSX!
