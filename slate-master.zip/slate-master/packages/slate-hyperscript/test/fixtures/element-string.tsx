/** @jsx jsx */
import { jsx } from 'slate-hyperscript'

export const input = <element>word</element>
export const output = {
  children: [
    {
      text: 'word',
    },
  ],
}
