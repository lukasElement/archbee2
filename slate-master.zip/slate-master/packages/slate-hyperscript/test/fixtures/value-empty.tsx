/** @jsx jsx */
import { jsx } from 'slate-hyperscript'

export const input = <editor />
export const output = {
  children: [],
  selection: null,
}
