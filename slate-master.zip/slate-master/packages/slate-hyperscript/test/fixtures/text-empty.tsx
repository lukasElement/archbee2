/** @jsx jsx */
import { jsx } from 'slate-hyperscript'

export const input = <text a />
export const output = {
  text: '',
  a: true,
}
