/** @jsx jsx */
import { jsx } from 'slate-hyperscript'

export const input = (
  <element>
    <element />
  </element>
)
export const output = {
  children: [
    {
      children: [],
    },
  ],
}
