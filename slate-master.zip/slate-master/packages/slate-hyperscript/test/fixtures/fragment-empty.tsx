/** @jsx jsx */
import { jsx } from 'slate-hyperscript'

export const input = <fragment />
export const output = []
