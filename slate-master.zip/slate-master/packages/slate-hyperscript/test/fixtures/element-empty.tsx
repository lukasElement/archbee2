/** @jsx jsx */
import { jsx } from 'slate-hyperscript'

export const input = <element />
export const output = {
  children: [],
}
