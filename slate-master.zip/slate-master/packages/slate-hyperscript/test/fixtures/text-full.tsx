/** @jsx jsx */
import { jsx } from 'slate-hyperscript'

export const input = <text a>word</text>
export const output = {
  text: 'word',
  a: true,
}
