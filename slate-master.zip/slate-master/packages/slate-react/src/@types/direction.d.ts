declare module 'direction' {
  function direction(text: string): 'neutral' | 'ltr' | 'rtl'
  export default direction
}
