This package contains the core logic of Slate. Feel free to poke around to learn more!

Note: A number of source files contain extracted types for `Interfaces` or `Transforms`. This is done currently to enable custom type extensions as found in `packages/src/interfaces/custom-types.ts`.
