---
'slate-react': patch
---

Fixed typo: Renamed `toSlatePoint` argument `extractMatch` to `exactMatch`
