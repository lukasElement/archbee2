---
'slate-react': patch
---

Fix errors accessing `globalThis` in browsers that do not implement it
