---
'slate-react': patch
---

Fix React warnings related to `autoCorrect` and `autoCapitalize` attributes being passed as a boolean instead of a string.
