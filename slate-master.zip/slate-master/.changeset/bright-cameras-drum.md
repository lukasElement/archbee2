---
'slate-react': patch
---

Removed accidental bundling of `slate-history` inside `slate-react`
